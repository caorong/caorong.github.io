This is blog theme compatible with Jekyll-Bootstrap

<http://jekyllbootstrap.com> for usage.